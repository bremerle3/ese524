% Copyright 1999 by Todd K. Moon
 
[y,ss] = hmmgendat(8,HMM);
