function x = fact(n)
% compute the factorial
x =prod(1:n);
